#include <Windows.h>
#include <iostream>
#include <string>
#include <thread>
#include <atomic>
#include <Psapi.h>
#include <shellapi.h>

// ȫ�ֱ����洢��һ�δ����Ĵ��ھ��
static HWND lastHandledWindow = nullptr;
static HWND lastFocusedWindow = nullptr;
static std::atomic<bool> killRequested(false);
static std::atomic<bool> hideRequested(false);
static std::atomic<bool> restartRequested(false);
static std::atomic<bool> coKillRequested(false);
static std::atomic<bool> coHideRequested(false); // ������co-hide�����־
static std::string lastProcessPath;

// ��ⴰ���Ƿ�ȫ��
bool IsFullscreenWindow(HWND hwnd) {
    if (!hwnd || hwnd == GetDesktopWindow() || hwnd == GetShellWindow()) {
        return false;
    }

    RECT windowRect;
    if (!GetWindowRect(hwnd, &windowRect)) {
        return false;
    }

    // ��ȡ����������ʾ������Ϣ
    HMONITOR monitor = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
    MONITORINFO monitorInfo = { sizeof(MONITORINFO) };
    if (!GetMonitorInfo(monitor, &monitorInfo)) {
        return false;
    }

    // �Ƚϴ��ڳߴ����ʾ���ߴ�
    const RECT& screenRect = monitorInfo.rcMonitor;
    return windowRect.left == screenRect.left &&
        windowRect.top == screenRect.top &&
        windowRect.right == screenRect.right &&
        windowRect.bottom == screenRect.bottom;
}

// ǿ�ƽ����ڴ��ڻ�
void ForceWindowedMode(HWND hwnd) {
    if (!hwnd || !IsWindow(hwnd)) return;

    std::cout << "Attempting to force window out of fullscreen..." << std::endl;

    // ��¼��ǰ�����Ĵ���
    lastHandledWindow = hwnd;

    // ��ȡ���������·��
    DWORD processId;
    GetWindowThreadProcessId(hwnd, &processId);
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, processId);
    if (hProcess) {
        char path[MAX_PATH];
        if (GetModuleFileNameExA(hProcess, NULL, path, MAX_PATH)) {
            lastProcessPath = path;
            std::cout << "Saved process path: " << lastProcessPath << std::endl;
        }
        else {
            std::cerr << "Failed to get process path. Error: " << GetLastError() << std::endl;
        }
        CloseHandle(hProcess);
    }
    else {
        std::cerr << "Failed to open process for path query. Error: " << GetLastError() << std::endl;
    }

    // ����1: ���Է��ͻ�ԭ����
    PostMessage(hwnd, WM_SYSCOMMAND, SC_RESTORE, 0);

    // ����2: �����л�������ʽ
    LONG_PTR style = GetWindowLongPtr(hwnd, GWL_STYLE);
    if (style) {
        // �Ƴ�ȫ����ص���ʽ
        style &= ~(WS_POPUP | WS_BORDER);
        style |= WS_OVERLAPPEDWINDOW;
        SetWindowLongPtr(hwnd, GWL_STYLE, style);
    }

    // ����3: ǿ�Ƶ������ڴ�С��λ��
    RECT rect;
    GetWindowRect(hwnd, &rect);
    rect.right = rect.left + 800;  // �¿���
    rect.bottom = rect.top + 600;  // �¸߶�

    // ��ȡ��Ļ����λ��
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    int centerX = (screenWidth - 800) / 2;
    int centerY = (screenHeight - 600) / 2;

    // Ӧ����λ�úʹ�С
    SetWindowPos(hwnd, HWND_TOP, centerX, centerY, 800, 600, SWP_SHOWWINDOW);

    // ˢ�´���
    ShowWindow(hwnd, SW_SHOWNORMAL);
    UpdateWindow(hwnd);
}

// ����ָ�����ڵĽ���
void KillWindowProcess(HWND hwnd) {
    if (!hwnd || !IsWindow(hwnd)) {
        std::cout << "Invalid window handle." << std::endl;
        return;
    }

    DWORD processId;
    GetWindowThreadProcessId(hwnd, &processId);
    if (!processId) {
        std::cout << "Failed to get process ID." << std::endl;
        return;
    }

    HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, processId);
    if (!hProcess) {
        std::cout << "Failed to open process. Error: " << GetLastError() << std::endl;
        return;
    }

    if (TerminateProcess(hProcess, 0)) {
        std::cout << "Process terminated successfully." << std::endl;
    }
    else {
        std::cout << "TerminateProcess failed. Error: " << GetLastError() << std::endl;
    }

    CloseHandle(hProcess);
}

// ��С��ָ������
void MinimizeWindow(HWND hwnd) {
    if (!hwnd || !IsWindow(hwnd)) {
        std::cout << "Invalid window handle." << std::endl;
        return;
    }

    // ��С������
    if (ShowWindow(hwnd, SW_MINIMIZE)) {
        std::cout << "Window minimized successfully." << std::endl;
    }
    else {
        std::cout << "Minimize failed. Error: " << GetLastError() << std::endl;
    }
}

// ��������
void RestartLastProcess() {
    if (lastProcessPath.empty()) {
        std::cout << "No saved process path to restart." << std::endl;
        return;
    }

    std::cout << "Attempting to restart: " << lastProcessPath << std::endl;

    // ʹ��ShellExecute��������
    HINSTANCE result = ShellExecuteA(
        NULL,               // �����ھ��
        "open",             // ����
        lastProcessPath.c_str(), // �ļ�·��
        NULL,               // ����
        NULL,               // ����Ŀ¼
        SW_SHOWNORMAL       // ��ʾ��ʽ
    );

    // ���ִ�н��
    if ((int)result <= 32) {
        std::cerr << "Failed to restart process. Error code: " << (int)result << std::endl;
    }
    else {
        std::cout << "Process restarted successfully." << std::endl;
    }
}

// ����̨��������߳�
void ConsoleInputListener() {
    std::string input;
    while (true) {
        std::getline(std::cin, input);
        if (input == "kill") {
            killRequested = true;
        }
        else if (input == "hide") {
            hideRequested = true;
        }
        else if (input == "restart") {
            restartRequested = true;
        }
        else if (input == "co-kill") {
            coKillRequested = true;
        }
        else if (input == "co-hide") { // ����������co-hide����
            coHideRequested = true;
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc > 1 && std::string(argv[1]) == "-h") {
        std::cout << "Usage: PreventFullScreen.exe" << std::endl;
        std::cout << "  -h: Show this help message." << std::endl;
        std::cout << "  Running: kill, hide, restart, co-kill, co-hide" << std::endl;
        std::cout << "    co-kill: Kill the last focused window." << std::endl;
        std::cout << "    co-hide: Minimize the last focused window." << std::endl;
        std::cout << "    kill: Kill the last handled window." << std::endl;
        std::cout << "    hide: Minimize the last handled window." << std::endl;
        std::cout << "    restart: Restart the last handled process." << std::endl;
    }

    // ��ȡ����̨���ھ���������ų�������
    HWND consoleWindow = GetConsoleWindow();

    // ��������̨��������߳�
    std::thread inputThread(ConsoleInputListener);
    inputThread.detach();

    bool wasFullscreen = false;

    while (true) {
        // ��ȡ��ǰ���㴰��
        HWND foregroundWindow = GetForegroundWindow();

        // ��¼��һ�ν��㴰�ڣ��ų�����̨������
        if (foregroundWindow && foregroundWindow != consoleWindow) {
            lastFocusedWindow = foregroundWindow;
        }

        // ����kill����
        if (killRequested) {
            if (lastHandledWindow && IsWindow(lastHandledWindow)) {
                std::cout << "Killing last handled window..." << std::endl;
                KillWindowProcess(lastHandledWindow);
            }
            else {
                std::cout << "No valid window to kill." << std::endl;
            }
            killRequested = false;
        }

        // ����hide����
        if (hideRequested) {
            if (lastHandledWindow && IsWindow(lastHandledWindow)) {
                std::cout << "Minimizing last handled window..." << std::endl;
                MinimizeWindow(lastHandledWindow);
            }
            else {
                std::cout << "No valid window to minimize." << std::endl;
            }
            hideRequested = false;
        }

        // ����restart����
        if (restartRequested) {
            std::cout << "Restarting last handled process..." << std::endl;
            RestartLastProcess();
            restartRequested = false;
        }

        // ����co-kill����
        if (coKillRequested) {
            if (lastFocusedWindow && IsWindow(lastFocusedWindow) && lastFocusedWindow != consoleWindow) {
                std::cout << "Killing last focused window..." << std::endl;
                KillWindowProcess(lastFocusedWindow);
            }
            else {
                std::cout << "No valid window to co-kill." << std::endl;
            }
            coKillRequested = false;
        }

        // ����co-hide����������
        if (coHideRequested) {
            if (lastFocusedWindow && IsWindow(lastFocusedWindow) && lastFocusedWindow != consoleWindow) {
                std::cout << "Minimizing last focused window..." << std::endl;
                MinimizeWindow(lastFocusedWindow);
            }
            else {
                std::cout << "No valid window to co-hide." << std::endl;
            }
            coHideRequested = false;
        }

        if (foregroundWindow) {
            bool isFullscreen = IsFullscreenWindow(foregroundWindow);

            // ��⵽����ȫ��״̬
            if (isFullscreen && !wasFullscreen) {
                std::cout << "Fullscreen detected! Forcing windowed mode..." << std::endl;
                ForceWindowedMode(foregroundWindow);
            }

            wasFullscreen = isFullscreen;
        }

        // ÿ500������һ��
        Sleep(500);
    }

    return 0;
}