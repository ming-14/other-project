Option Explicit
include "bin/base.vbs"
include "bin/add.vbs"

Dim PdCPath : PdCPath = FindInstallPath("С��èC++")

Dim isSuccessful : isSuccessful = False
If FileExists("%APPDATA%\RedPandaIDE\redpandacpp.ini") Then
	Call AddConfig(CreateObject("WScript.Shell").ExpandEnvironmentStrings("%APPDATA%\RedPandaIDE\redpandacpp.ini"), "push.ini")
	isSuccessful = True
End If
If FileExists(FindInstallPath("С��èC++") & "\config\redpandacpp.ini") Then
	Call AddConfig(PdCPath & "\config\redpandacpp.ini", "push.ini")
	isSuccessful = True
End If

If isSuccessful Then
	msgbox "�������˼ҲŲ���������˼�Ҫ�� mingw64-ucrt-15.2.0-r1.7z ���Ƶ� " & chr(34) & PdCPath & "\mingw64" & chr(34)
	CreateObject("WScript.Shell").Run "bin\ins.bat " & chr(34) & PdCPath & "\mingw64" & chr(34)
Else
	Msgbox("�������˼ҷ����� AppData��config\redpandacpp.ini����û��")
	WScript.Quit 1
End If

Function include(sInstFile)
    Dim oFSO : Set oFSO = CreateObject("Scripting.FileSystemObject")
    Dim f : Set f = oFSO.OpenTextFile(sInstFile)
    Dim s : s = f.ReadAll
    f.Close
    ExecuteGlobal s
End Function
